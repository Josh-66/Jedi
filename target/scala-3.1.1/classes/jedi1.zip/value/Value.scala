package value

trait Value