package expression
import context.Environment
import value.{Boole, Notification, Value}

case class Iteration(cond: Expression, body:Expression) extends SpecialForm {
  override def execute(env: Environment): Value = {
    while(cond.execute(env) == Boole.TRUE){
      body.execute(env)
    }
    Notification.DONE
  }
}
